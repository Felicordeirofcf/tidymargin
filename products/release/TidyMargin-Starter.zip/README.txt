TidyMargin - Starter
====================================

Thank you for your purchase!

START HERE
1. Open TidyMargin-Starter-EXAMPLE.xlsx to see the kit filled with a fictional business.
2. Use TidyMargin-Starter.xlsx for your own business. Fill in the Settings sheet first.
3. Read TidyMargin-User-Guide.pdf (15 minutes).

GOOGLE SHEETS
Upload the .xlsx to Google Drive, open it, then File > Save as Google Sheets.

EXCEL
Excel 2019, 2021, Microsoft 365 or the free Excel for the web. No macros.

All default numbers are examples. Replace them with your own costs.
TidyMargin is a business-management tool, not accounting, tax or legal advice.

LICENSE: one business, any number of its own devices. Please do not resell or share.
SUPPORT: tidymargin.help@gmail.com (reply within 2 business days).
Version 1.0 (2026-11)
