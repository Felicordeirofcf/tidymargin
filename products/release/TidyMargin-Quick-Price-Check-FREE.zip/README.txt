TidyMargin Quick Price Check (free)

Open the .xlsx in Excel or Google Sheets.
Yellow cells are yours. The full kit is on the TidyMargin store.
